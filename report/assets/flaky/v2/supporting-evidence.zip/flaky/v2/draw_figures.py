"""Render v2 report figures from archived ZIPs/metadata (matplotlib + Pillow)."""
from pathlib import Path
import json
import zipfile
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
TRIAGE = HERE.parents[1] / "triage" / "v2"
FONT = Path("C:/Windows/Fonts/segoeui.ttf")
BOLD = Path("C:/Windows/Fonts/segoeuib.ttf")
NAVY, BLUE, GREEN, RED = "#192e49", "#29649a", "#34744b", "#a5453e"


def trace(packet, run, attempt):
    with zipfile.ZipFile(packet) as archive:
        events = [json.loads(line) for line in archive.read(f"{run}/events.jsonl").splitlines()]
    subset = [e for e in events if e["attempt"] == attempt]
    request = {}
    for operation in ("submit", "history", "confirmation"):
        sent = next(e for e in subset if e["event"] == "http.client.sent" and e["operation"] == operation)
        received = next(e for e in subset if e["event"] == "http.client.received" and e["operation"] == operation)
        assert received["status_code"] == 200
        request[operation] = (sent["elapsed_ms"], received["elapsed_ms"])
    snapshot = next(e for e in subset if e["event"] == "http.client.received" and e["operation"] == "history")
    result = next(e for e in subset if e["event"] == "attempt.finished")
    return request, snapshot["response"]["order_count"], result["status"]


def timeline():
    if FONT.exists():
        font_manager.fontManager.addfont(str(FONT))
        plt.rcParams["font.family"] = font_manager.FontProperties(fname=str(FONT)).get_name()
    baseline = TRIAGE / "ai-sol/api-analysis-input-39860438568-1.zip"
    corrected = HERE / "e09-ci/api-analysis-input-39911447981-1.zip"
    cases = [(baseline, "run-02", 1, "TIMED — run-02, attempt 1", "failed"),
             (baseline, "run-02", 2, "TIMED — run-02, attempt 2 (fixture mới)", "passed"),
             (corrected, "run-01", 1, "AWAITED — run-01, attempt 1; không retry", "passed")]
    fig, axes = plt.subplots(3, 1, figsize=(14, 10.8), layout="constrained")
    fig.suptitle("THỨ TỰ ĐẶT HÀNG VÀ ĐỌC LỊCH SỬ", fontsize=22, color=NAVY, weight="bold")
    for ax, (packet, run, attempt, title, expected) in zip(axes, cases):
        request, count, status = trace(packet, run, attempt)
        assert status == expected and count == (1 if status == "passed" else 0)
        origin = request["submit"][0]
        color = GREEN if status == "passed" else RED
        ax.set_title(f"{title} — {status.upper()}", loc="left", fontsize=15, color=color, pad=12)
        labels = ["POST checkout (200)", f"GET history ({count} đơn)", "GET confirmation (1 đơn)"]
        for y, (op, fill) in enumerate(zip(("submit", "history", "confirmation"), (BLUE, color, "#7b8696"))):
            start, end = (value - origin for value in request[op])
            ax.barh(y, end-start, left=start, height=.26, color=fill)
            ax.scatter([start, end], [y, y], s=20, color=fill, zorder=3)
            ax.annotate(f"{start:.3f}", (start, y), xytext=(0, 12), textcoords="offset points", ha="center", fontsize=10, color=NAVY)
            ax.annotate(f"{end:.3f}", (end, y), xytext=(0, -19), textcoords="offset points", ha="center", fontsize=10, color=NAVY)
        ax.set_yticks(range(3), labels, fontsize=12)
        ax.set_ylim(2.65, -.65)
        ax.set_xlim(-8, 220)
        ax.set_xticks([0, 50, 100, 150, 200])
        ax.grid(axis="x", color="#dce3eb", linewidth=.8)
        ax.set_axisbelow(True)
        ax.set_xlabel("ms từ lúc client gửi POST của từng attempt", fontsize=11)
        for side in ("top", "right", "left"):
            ax.spines[side].set_visible(False)
        ax.tick_params(axis="y", length=0)
    fig.savefig(HERE / "order-history-timeline.png", dpi=180, facecolor="white")
    plt.close(fig)


def font(size, bold=False):
    return ImageFont.truetype(str(BOLD if bold else FONT), size)


def wrap(draw, text, width, size):
    lines, line = [], ""
    for word in text.split():
        candidate = (line + " " + word).strip()
        if draw.textlength(candidate, font=font(size)) > width and line:
            lines.append(line)
            line = word
        else:
            line = candidate
    return lines + [line]


def box(draw, rect, title, body, color=BLUE, size=35):
    x1, y1, x2, y2 = rect
    draw.rounded_rectangle(rect, radius=22, fill="#f3f6fa", outline=color, width=4)
    y = y1 + 22
    for line in wrap(draw, title, x2-x1-44, size+3):
        draw.text((x1+22, y), line, font=font(size+3, True), fill=NAVY)
        y += size+15
    y += 12
    for line in wrap(draw, body, x2-x1-44, size):
        draw.text((x1+22, y), line, font=font(size), fill=NAVY)
        y += size+12
    assert y < y2-5, (title, y, y2)


def arrow(draw, a, b):
    draw.line([a, b], fill=BLUE, width=5)
    x, y = b
    draw.polygon([(x, y), (x-12, y-18), (x+12, y-18)], fill=BLUE)


def triage():
    meta = json.loads((TRIAGE / "ai-sol/metadata.json").read_text(encoding="utf-8"))
    result = json.loads((HERE / "e09-ci/batch.json").read_text(encoding="utf-8"))
    image = Image.new("RGB", (2400, 1420), "white")
    draw = ImageDraw.Draw(image)
    title = "CÙNG PACKET V2, HAI BẢN PHÂN TÍCH"
    width = draw.textlength(title, font=font(58, True))
    draw.text(((2400-width)/2, 40), title, font=font(58, True), fill=NAVY)
    box(draw, (450, 155, 1950, 365), "Batch timed — CI 39860438568",
        "10 run • 19 attempt • 9 retry; ZIP analysis dùng chung. Organizer và source giữ cho bước xác minh.")
    arrow(draw, (900, 365), (660, 450))
    arrow(draw, (1500, 365), (1740, 450))
    minutes = meta["human_analysis_duration_seconds"] // 60
    box(draw, (130, 450, 1190, 780), "Vượng — phân tích thủ công",
        f"Hoàn thiện trước khi xem AI; {minutes} phút. Giả thuyết, dẫn chứng và ba hướng kiểm tra.", color=GREEN)
    box(draw, (1270, 450, 2270, 780), meta["model"],
        f"ci-log-triage: chỉ đọc packet. {meta['reported_seconds_to_evidence_cutoff']} giây đến chốt bằng chứng; chưa gồm soạn trả lời.")
    arrow(draw, (660, 780), (1000, 880))
    arrow(draw, (1760, 780), (1500, 880))
    box(draw, (340, 880, 2060, 1095), "E-08 — đối chiếu năm tiêu chí",
        "Nguyên nhân • bằng chứng • next-checks • phạm vi thời gian • suy diễn. Đồng thuận chưa tự xác nhận nguyên nhân.")
    arrow(draw, (1200, 1095), (1200, 1160))
    assert result["summary"]["first_attempt_pass"] == 10 and result["retry_limit"] == 0
    box(draw, (340, 1160, 2060, 1360), "E-09 — xác nhận riêng sau triage",
        "CI 39911447981: awaited, 10/10 PASS không retry. Mọi POST hoàn tất trước GET; không phải skill tự sửa mã.", color=GREEN, size=33)
    image.save(TRIAGE / "human-ai-flow.png")


if __name__ == "__main__":
    timeline()
    triage()
    print("Generated v2 timeline from original event times and explanatory human–AI flow from metadata.")
