"""Generate explanatory report figures from preserved experiment evidence."""
from pathlib import Path
import json
from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
NAVY = "#192e49"
BLUE = "#29649a"
GREEN = "#34744b"
RED = "#a5453e"
GRAY = "#64748b"
PALE = "#f3f6fa"
FONT = Path("C:/Windows/Fonts/segoeui.ttf")
BOLD = Path("C:/Windows/Fonts/segoeuib.ttf")


def font(size, bold=False):
    return ImageFont.truetype(str(BOLD if bold else FONT), size)


def center(draw, text, y, size=42, color=NAVY, bold=False, width=2400):
    box = draw.textbbox((0, 0), text, font=font(size, bold))
    draw.text(((width-(box[2]-box[0]))/2, y), text, font=font(size, bold), fill=color)


def wrap(draw, text, width, size):
    lines = []
    for paragraph in text.split("\n"):
        line = ""
        for word in paragraph.split():
            candidate = (line+" "+word).strip()
            if draw.textlength(candidate, font=font(size)) > width and line:
                lines.append(line)
                line = word
            else:
                line = candidate
        lines.append(line)
    return lines


def box(draw, rect, title, body, color=BLUE, size=35):
    x1, y1, x2, y2 = rect
    draw.rounded_rectangle(rect, radius=22, fill=PALE, outline=color, width=4)
    lines = wrap(draw, title, x2-x1-44, size+3)
    y = y1+22
    for line in lines:
        draw.text((x1+22,y),line,font=font(size+3,True),fill=NAVY)
        y += size+15
    y += 12
    for line in wrap(draw,body,x2-x1-44,size):
        draw.text((x1+22,y),line,font=font(size),fill=NAVY)
        y += size+12
    assert y < y2-5, (title,y,y2)


def arrow(draw, a, b, color=BLUE):
    draw.line([a,b],fill=color,width=5)
    x,y=b
    if abs(b[0]-a[0]) >= abs(b[1]-a[1]):
        sign=1 if b[0]>a[0] else -1
        draw.polygon([(x,y),(x-sign*18,y-12),(x-sign*18,y+12)],fill=color)
    else:
        sign=1 if b[1]>a[1] else -1
        draw.polygon([(x,y),(x-12,y-sign*18),(x+12,y-sign*18)],fill=color)


def timeline():
    batch=json.loads((HERE/"evidence/e03/batch.json").read_text(encoding="utf-8"))
    fixed=json.loads((HERE/"evidence/e09/verification.json").read_text(encoding="utf-8"))
    cases=[("TRƯỚC SỬA — CI, lượt 02 PASS",batch["runs"][1]["timing"],GREEN),
           ("TRƯỚC SỬA — CI, lượt 01 FAIL",batch["runs"][0]["timing"],RED),
           ("SAU SỬA — local, chế độ slow PASS",fixed["after"][1]["observation"],GREEN)]
    image=Image.new("RGB",(2400,1460),"white"); draw=ImageDraw.Draw(image)
    center(draw,"THỨ TỰ THÊM VÀ ĐỌC GIỎ HÀNG",35,60,bold=True)
    center(draw,"Mốc thời gian thực tế từ log; mỗi lượt có gốc thời gian riêng",120,36)
    x0,xend=590,2210
    def x(ms): return x0+ms/200*(xend-x0)
    for index,(title,t,color) in enumerate(cases):
        y=220+index*360
        draw.rounded_rectangle((70,y,2330,y+325),radius=20,outline="#d4dce6",width=2)
        draw.text((105,y+18),title,font=font(39,True),fill=color)
        for j,(label,start,end) in enumerate([("A — POST thêm",t["addSentMs"],t["addCompletedMs"]),("B — GET giỏ",t["readSentMs"],t["readCompletedMs"])]):
            yy=y+123+j*85
            draw.text((110,yy-25),label,font=font(34,True),fill=NAVY)
            draw.line((x0,yy,xend,yy),fill="#d7dfe8",width=3)
            draw.line((x0,yy,x(start),yy),fill="#93a2b3",width=3)
            draw.rounded_rectangle((x(start),yy-12,max(x(start)+5,x(end)),yy+12),radius=5,fill=color)
            draw.ellipse((x(start)-6,yy-6,x(start)+6,yy+6),fill=NAVY)
            draw.ellipse((x(end)-6,yy-6,x(end)+6,yy+6),fill=color)
            for tick in [0,50,100,150,200]:
                draw.line((x(tick),yy+20,x(tick),yy+27),fill=GRAY,width=2)
                draw.text((x(tick)-18,yy+30),str(tick),font=font(24),fill=GRAY)
        numbers=(f"POST: {t['addSentMs']:.3f} → {t['addCompletedMs']:.3f} ms     "
                 f"GET: {t['readSentMs']:.3f} → {t['readCompletedMs']:.3f} ms")
        center(draw,numbers,y+272,31)
    center(draw,"Đoạn đậm: request đã gửi → hoàn tất. Không dùng hình này để so tốc độ CI với local.",1350,32)
    image.save(HERE/"cart-timeline.png")


def triage():
    dest=HERE.parent/"triage"; dest.mkdir(exist_ok=True)
    image=Image.new("RGB",(2400,1370),"white"); draw=ImageDraw.Draw(image)
    center(draw,"CÙNG DỮ LIỆU, HAI BẢN PHÂN TÍCH",40,60,bold=True)
    box(draw,(450,155,1950,355),"Gói E-05 đã chuẩn hóa","10 lượt độc lập • console + Jest JSON + lịch sử chạy • retry bằng 0",size=36)
    arrow(draw,(900,355),(660,450)); arrow(draw,(1500,355),(1740,450))
    box(draw,(130,450,1190,750),"Vượng — phân tích thủ công","Quan sát → giả thuyết → dẫn chứng → bước kiểm tra. Hoàn thành trước khi xem Sol; thời lượng 20 phút.",color=GREEN,size=36)
    box(draw,(1270,450,2270,750),"Codex GPT-6.1 Sol","Áp dụng ci-log-triage: chỉ đọc dữ liệu; tối đa 3 giả thuyết và 3 bước xác minh. Thời lượng 1 phút 30 giây.",size=36)
    arrow(draw,(660,750),(1000,850)); arrow(draw,(1760,750),(1500,850))
    box(draw,(340,850,2060,1065),"Đối chiếu E-08","Nguyên nhân • bằng chứng • bước tiếp theo • thời gian • suy diễn. Đồng thuận không đồng nghĩa đã xác nhận bằng thực nghiệm.",size=36)
    arrow(draw,(1200,1065),(1200,1130))
    box(draw,(340,1130,2060,1315),"Xác minh riêng ở E-09","Tái hiện lỗi → sửa cách đồng bộ → 12/12 lượt local PASS. Đây là bước sau triage, không phải skill tự sửa mã.",color=GREEN,size=34)
    image.save(dest/"human-ai-flow.png")


def reuse():
    dest=HERE.parent/"triage"
    image=Image.new("RGB",(2400,1130),"white"); draw=ImageDraw.Draw(image)
    center(draw,"ÁP DỤNG CHO DỰ ÁN KHÁC",40,60,bold=True)
    tiles=[("1. Hợp đồng kiểm thử","Lệnh chạy thật, assertion theo yêu cầu; fixture riêng và cleanup."),
           ("2. CI và bằng chứng","Cố định runtime/lockfile; giữ exit code, log, report và artifact."),
           ("3. Lịch sử có ngữ cảnh","Cùng revision/điều kiện; phân biệt lượt mới, rerun và retry."),
           ("4. Phân tích có giới hạn","Cùng dữ liệu cho người và AI; dẫn chứng, giả thuyết, mức chắc chắn."),
           ("5. Xác minh có kiểm soát","Thay đổi có mục tiêu; giữ trước/sau và ghi phiên bản mới."),
           ("6. Phản hồi vào dự án","Review kết quả, xử lý nguyên nhân; không retry đến khi xanh.")]
    positions=[(100,185,800,535),(850,185,1550,535),(1600,185,2300,535),(100,650,800,1000),(850,650,1550,1000),(1600,650,2300,1000)]
    for pos,(title,body) in zip(positions,tiles): box(draw,pos,title,body,size=36)
    arrow(draw,(800,360),(850,360)); arrow(draw,(1550,360),(1600,360))
    arrow(draw,(1950,535),(1950,592)); draw.line((1950,592,450,592),fill=BLUE,width=5); arrow(draw,(450,592),(450,650))
    arrow(draw,(800,825),(850,825)); arrow(draw,(1550,825),(1600,825))
    image.save(dest/"reuse-flow.png")


if __name__=="__main__":
    timeline(); triage(); reuse()
    print("Generated 3 figures from preserved data and documented workflow.")
