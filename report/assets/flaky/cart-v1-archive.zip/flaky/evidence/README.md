# Minh chứng thí nghiệm flaky test cho chương 8

> **Hồ sơ v1 — cart.** Giữ đường dẫn và dữ liệu cũ phục vụ tra cứu. Bộ hiện hành nằm tại [v2 — order history](../v2/README.md); không dùng số liệu v1 thay cho kết quả v2.

Bằng chứng được sao chép từ repository mã nguồn `SUT-group10/eshop-sut-group10`, checkout `115df94`, ngày 23/10/2026. Các file copy đã được đối chiếu nguyên byte với nguồn tại lúc thu; không chạy lại test hoặc workflow khi biên soạn chương này. [source-index.json](source-index.json) liệt kê đường dẫn nguồn và bản lưu cho cả phần flaky và triage.

## Bộ E-03 trước sửa

- [e03/batch.json](e03/batch.json) lưu điều kiện, SHA đo `b252db4aa9e236b78879dfbbf7b882cdadb8580c`, metadata và kết quả 10 lượt ngày 21/10/2026.
- Các thư mục `e03/01-39623369899` đến `e03/10-39629561358` giữ console, Jest JSON, metadata run/job/artifact và các ZIP tải từ CI. Không bỏ lượt fail hoặc dùng rehearsal thay mẫu.
- [github-verification-20261023.json](github-verification-20261023.json) là kiểm tra lại trạng thái qua GitHub API ngày 23/10/2026: 10 run completed, 5 success/5 failure, cùng SHA, run_attempt 1. PR #18 đã merge. Đây là kiểm tra metadata mới, không phải một đợt thực thi mới.
- Giữ nguyên các metadata cũ có trường job completed_at null; không tự điền duration. Chương 8 dùng duration test từ Jest, không dùng khoảng workflow cập nhật để thay thời gian job.

## Bản sửa và E-09 local

- [config/cart-after.js](config/cart-after.js) là bản test sau sửa; [e09/before-source.js](e09/before-source.js) là snapshot trước sửa.
- [config/flaky-experiment.yml](config/flaky-experiment.yml), [config/jest.flaky.config.cjs](config/jest.flaky.config.cjs) và [config/jest.config.cjs](config/jest.config.cjs) cho thấy chế độ chạy riêng. Nội dung workflow dùng trong E-03 được truy vết theo SHA trong batch.
- [e09/verification.json](e09/verification.json) lưu một lượt slow trước sửa fail, 12 lượt sau sửa pass, lệnh và môi trường Windows/Node 24.14.0/npm 11.21.0. [e09/fix.patch](e09/fix.patch) giữ thay đổi đã kiểm chứng; commit bản sửa `3a6290d` được ghi sau lần chạy local.
- Các file `before-slow.*`, `after-XX-*.*`, `lint.log` và `build.log` là dữ liệu thật được lưu ở E-09. Console local được ghi stdout rồi stderr; không dùng thứ tự giữa hai stream để suy timeline, mà dùng các mốc observation.

Các field thời gian trong dữ liệu gốc giữ nguyên ký pháp nguồn. Khi hiển thị trong văn bản tiếng Việt, báo cáo có thể dùng dấu phẩy thập phân; không đổi giá trị dữ liệu.

## Hình minh họa

[draw_figures.py](../draw_figures.py) tạo ba hình PNG của phần flaky/triage. Timeline đọc trực tiếp dữ liệu E-03/E-09, không tự ước lượng thời điểm. Hai flowchart còn lại là sơ đồ giải thích quy trình, không phải screenshot CI hoặc bằng chứng model thực thi từng công cụ. Hình dùng nền trắng và font Segoe UI trên Windows; script cần Pillow, đã có trong môi trường biên soạn.

Không thêm checksum mới cho từng tài liệu. Các manifest cũ nếu nằm trong gói input vẫn thuộc bằng chứng gốc, không được diễn giải thành đo hiệu quả công cụ.
