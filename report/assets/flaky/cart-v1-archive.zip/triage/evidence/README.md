# Minh chứng người–AI cho chương 9 và 10

> **Hồ sơ v1 — cart.** Thời lượng Sol 90 giây và kết quả dưới đây thuộc v1. [Hồ sơ v2](../v2/README.md) được lưu riêng; bản skill có nguồn/giấy phép ở đây được dùng chung cho cả hai đợt.

Bản lưu phục vụ đối chiếu đúng dữ liệu và output đã bàn giao, không phải một lượt phân tích AI mới khi viết report.

| File / folder | Nguồn và vai trò |
| --- | --- |
| [participant-input.zip](participant-input.zip) | ZIP E-05 dùng chung cho hai bên; copy nguyên byte từ repo mã nguồn |
| [participant-input](participant-input) | Bản các file tương ứng của gói E-05: input có số dòng, history và console/JSON của 10 lượt |
| [phan-tich-vuong.md](phan-tich-vuong.md) | Bản phân tích do Vượng thực hiện trong 20 phút, hoàn thiện trước khi xem output Sol |
| [analysis-context.json](analysis-context.json) | Người phân tích, thứ tự thực hiện và thời lượng: Vượng 20 phút, Sol 1 phút 30 giây |
| [ai-sol/response.md](ai-sol/response.md) | Output nguyên văn được người dùng dán lại, Codex GPT-6.1 Sol theo xác nhận |
| [ai-sol/prompt.md](ai-sol/prompt.md) | Prompt được cung cấp lại, còn dấu ba chấm và lược đường dẫn cá nhân; không tự dựng thành export phiên gốc |
| [ai-sol/metadata.json](ai-sol/metadata.json) | Nguồn của công cụ/model, ngày ghi nhận và dữ kiện đã có ở lần lưu trước |
| [ci-log-triage/SKILL.md](ci-log-triage/SKILL.md) | Bản skill chốt ở E-06; chỉ phân tích dữ liệu được giao |
| [ci-log-triage/SOURCES.md](ci-log-triage/SOURCES.md), [LICENSE.txt](ci-log-triage/LICENSE.txt) | Nguồn systematic-debugging, phiên bản, các điều chỉnh và MIT license |

Bản phân tích thủ công và analysis-context.json ghi thời lượng Vượng 20 phút cùng trình tự hoàn thiện trước khi xem Sol. Output và metadata Sol ghi thời lượng 1 phút 30 giây; không dùng thời lượng phân tích thay cho tổng công sức review và xác minh.

Không có toàn bộ tool trace hoặc mốc bắt đầu/kết thúc của phiên Sol, nên báo cáo không tự dựng timestamp, số lần thử hoặc chứng nhận mọi tài nguyên model đã đọc. Hồ sơ chỉ lưu một output được cung cấp; không suy ra đây là lần thử duy nhất từng thực hiện.

Người phân tích không nhận các file tổ chức có đáp án. Thư mục này phục vụ báo cáo sau thí nghiệm; khi làm lượt độc lập chỉ cấp bản hướng dẫn phù hợp và ZIP. Nguồn snapshot và đường dẫn copy được liệt kê tại [source-index](../../flaky/evidence/source-index.json).
